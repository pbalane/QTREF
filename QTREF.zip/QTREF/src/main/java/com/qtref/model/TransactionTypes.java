package com.qtref.model;

public enum TransactionTypes {
    CREDIT,
    DEBIT,
    TRANSFER
}
